/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, BookOpen, Sparkles, Loader2, ExternalLink, ChevronRight, FileText, Hash } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { searchRelatedPapers } from './services/geminiService';

interface Source {
  uri: string;
  title: string;
}

export default function App() {
  const [paperType, setPaperType] = useState('');
  const [keywords, setKeywords] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ text: string; sources: Source[] } | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paperType || !keywords) return;

    setLoading(true);
    try {
      const data = await searchRelatedPapers(paperType, keywords);
      setResult(data);
    } catch (error) {
      console.error('Search failed:', error);
      setResult({ text: '搜索过程中出现错误，请稍后再试。', sources: [] });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
              <BookOpen size={20} />
            </div>
            <h1 className="text-xl font-semibold tracking-tight">PaperInsight</h1>
          </div>
          <div className="text-sm text-gray-500 font-medium">论文灵感检索助手</div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-[400px_1fr] gap-12">
          {/* Left Column: Input Form */}
          <div className="space-y-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">开始你的研究</h2>
              <p className="text-gray-500">输入论文类型和核心关键词，我们将为你检索最相关的学术见解。</p>
            </div>

            <form onSubmit={handleSearch} className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <FileText size={16} className="text-indigo-500" />
                    论文类型
                  </label>
                  <input
                    type="text"
                    placeholder="例如：计算机视觉、环境经济学、临床医学..."
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all bg-white shadow-sm"
                    value={paperType}
                    onChange={(e) => setPaperType(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Hash size={16} className="text-indigo-500" />
                    核心关键词
                  </label>
                  <textarea
                    placeholder="输入关键词，用逗号分隔..."
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all bg-white shadow-sm resize-none"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !paperType || !keywords}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white font-semibold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 group"
              >
                {loading ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : (
                  <>
                    <Search size={20} className="group-hover:scale-110 transition-transform" />
                    立即检索
                  </>
                )}
              </button>
            </form>


          </div>

          {/* Right Column: Results */}
          <div className="min-h-[600px]">
            <AnimatePresence mode="wait">
              {!result && !loading && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="h-full flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-gray-200 rounded-3xl bg-white/50"
                >
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-4">
                    <Search size={32} />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">等待检索</h3>
                  <p className="text-gray-500 max-w-xs mt-2">在左侧输入信息并点击“立即检索”开始你的研究之旅。</p>
                </motion.div>
              )}

              {loading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center space-y-4"
                >
                  <div className="relative">
                    <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Sparkles size={16} className="text-indigo-600 animate-pulse" />
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-gray-900">正在检索学术资源...</p>
                    <p className="text-sm text-gray-500">这可能需要几秒钟时间</p>
                  </div>
                </motion.div>
              )}

              {result && !loading && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-8"
                >
                  <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 space-y-6">
                    <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                      <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        <Sparkles size={20} className="text-amber-500" />
                        检索见解
                      </h3>
                      <button 
                        onClick={() => window.print()}
                        className="text-xs font-medium text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-full transition-colors"
                      >
                        导出结果
                      </button>
                    </div>

                    <div className="prose prose-indigo max-w-none">
                      <div className="whitespace-pre-wrap text-gray-700 leading-relaxed text-lg">
                        {result.text}
                      </div>
                    </div>

                    {result.sources.length > 0 && (
                      <div className="pt-6 border-t border-gray-100">
                        <h4 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2">
                          <ExternalLink size={16} className="text-gray-400" />
                          参考来源
                        </h4>
                        <div className="grid gap-3">
                          {result.sources.map((source, idx) => (
                            <a
                              key={idx}
                              href={source.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center justify-between p-3 rounded-xl bg-gray-50 hover:bg-indigo-50 border border-gray-100 hover:border-indigo-200 transition-all group"
                            >
                              <div className="flex items-center gap-3 overflow-hidden">
                                <div className="w-6 h-6 bg-white rounded flex items-center justify-center text-[10px] font-bold text-gray-400 border border-gray-200">
                                  {idx + 1}
                                </div>
                                <span className="text-sm font-medium text-gray-700 truncate group-hover:text-indigo-700">
                                  {source.title}
                                </span>
                              </div>
                              <ChevronRight size={16} className="text-gray-300 group-hover:text-indigo-400 transition-colors shrink-0" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-5xl mx-auto px-6 py-12 border-t border-gray-200 mt-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 opacity-50">
            <BookOpen size={16} />
            <span className="text-xs font-bold uppercase tracking-widest">PaperInsight v1.0</span>
          </div>
          <div className="text-xs text-gray-400">
            基于 Google Gemini AI 提供学术检索支持
          </div>
        </div>
      </footer>
    </div>
  );
}
