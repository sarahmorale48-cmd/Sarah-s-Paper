import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface PaperResult {
  title: string;
  summary: string;
  relevance: string;
  sourceUrl: string;
}

export async function searchRelatedPapers(type: string, keywords: string): Promise<{ text: string, sources: { uri: string, title: string }[] }> {
  const prompt = `你是一个专业的学术检索助手。请针对以下课题进行真实、准确的学术检索：
论文类型：${type}
关键词：${keywords}

**严格指令（防止虚假信息）：**
1. **仅限真实来源：** 你必须使用 Google Search 工具检索真实的学术论文、预印本（arXiv）或官方研究报告。**严禁编造**不存在的论文、作者或页码。
2. **实时验证：** 每一个提到的观点必须对应检索到的真实网页内容。
3. **双重引用格式（核心要求）：** 对于检索到的每一篇核心文献，请在结果末尾或对应段落提供以下两种标准的引用格式，方便用户直接复制粘贴：
   - **附录格式（编号列表）：** 格式参考：[序号] 作者：《标题》，《期刊/会议名》，第X页，年份。
   - **脚标格式（括号内联）：** 格式参考：（作者：《标题》，《期刊/会议名》，年份年第X期，第X页）
4. **原文摘录（新增）：** 对于每一篇核心文献，请尝试摘录一段最相关的**原文片段**（Direct Quote）。如果原文是英文，请提供原文并附上中文翻译。
5. **结构化输出：**
   - **核心关联研究：** 总结检索到的最相关的 3-5 篇论文，附上引用格式及**原文摘录**。
   - **技术/理论路径：** 它们是如何解决问题的。
   - **对用户的启发：** 基于上述真实文献的建议。

如果你无法找到与关键词匹配的真实论文，请告知用户并建议更通用的关键词。`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const text = response.text || "未能找到相关内容，请尝试更换关键词。";
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.filter(chunk => chunk.web)
    ?.map(chunk => ({
      uri: chunk.web!.uri,
      title: chunk.web!.title || "参考来源"
    })) || [];

  return { text, sources };
}
